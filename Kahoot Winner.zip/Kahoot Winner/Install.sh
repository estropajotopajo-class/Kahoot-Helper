#!/usr/bin/env bash
# setup.sh - Instalador completo de dependencias para Kahoot Winner

set -e

echo "============================================================"
echo "⚡ Instalando ENTORNO COMPLETO para Kahoot Winner..."
echo "============================================================"

# 1. Actualización e instalación de paquetes base del sistema y GUI
echo "📦 [1/3] Instalando herramientas del sistema, motor gráfico y utilidades..."
sudo apt update
sudo apt install -y \
    python3 \
    python3-pip \
    python3-dev \
    flameshot \
    libgirepository1.0-dev \
    gir1.2-appindicator3-0.1 \
    libayatana-appindicator3-1 \
    gnome-shell-extension-appindicator \
    curl

# 2. Instalación forzada con --break-system-packages de TODAS las librerías de Python necesarias
echo "🐍 [2/3] Instalando todas las librerías de Python (Google Gemini API, PIL, Pynput, Pystray, Dotenv, Requests)..."
python3 -m pip install --break-system-packages \
    pillow \
    pynput \
    pystray \
    requests \
    python-dotenv \
    google-generativeai \
    urllib3

# 3. Asignación de permisos de ejecución
echo "🔑 [3/3] Configurando permisos de ejecución..."
chmod +x kahoot_winner.py setup.sh 2>/dev/null || chmod +x kahoot_winner.py

# 4. Verificación de entorno y estado final
echo "============================================================"
if [ -f .env ]; then
    echo "✅ Archivo '.env' localizado correctamente."
else
    echo "⚠️  AVISO: No se encontró el archivo '.env' en esta carpeta."
    echo "👉 Recuerda crear el '.env' con tu lista de API Keys de Gemini:"
    echo "   GEMINI_API_KEYS=Clave1,Clave2,Clave3..."
fi

echo "============================================================"
echo "🎉 ¡Todo instalado correctamente al 100%!"
echo "🚀 Ya puedes ejecutar el bot con: ./kahoot_winner.py"
echo "============================================================"