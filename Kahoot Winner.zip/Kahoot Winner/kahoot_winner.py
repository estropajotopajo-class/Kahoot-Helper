#!/usr/bin/env python3
# kahoot_winner.py

import io
import subprocess
import time
import hashlib
import threading
import os
import sys
import base64
import requests
from PIL import Image, ImageDraw
from pynput import keyboard
import pystray

# Cargar .env de la misma carpeta del script
try:
    from dotenv import load_dotenv
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
    load_dotenv(env_path)
except ImportError:
    pass

KEYS_RAW = os.environ.get("GEMINI_API_KEYS", "").strip() or os.environ.get("GEMINI_API_KEY", "").strip()


def crear_imagen_emoji(emoji=None):
    """Crea una imagen de 32x32. Si emoji es None, devuelve un icono 100% transparente."""
    img = Image.new('RGBA', (32, 32), color=(0, 0, 0, 0))
    if not emoji:
        return img

    colores = {
        "🔴": (235, 50, 35),
        "🟢": (38, 160, 38),
        "🔵": (19, 104, 206),
        "🟡": (242, 180, 0)
    }
    color_rgb = colores.get(emoji, (128, 128, 128))
    
    draw = ImageDraw.Draw(img)
    draw.ellipse((4, 4, 28, 28), fill=color_rgb)
    return img


class KahootWinnerBar:
    def __init__(self):
        print("=" * 60)
        print("⚡ Kahoot Winner - Verificando entorno...")
        print("=" * 60)

        # 1. Comprobación de API Keys
        self.api_keys = [k.strip() for k in KEYS_RAW.split(",") if k.strip()]
        if not self.api_keys:
            print("❌ ERROR: No se encontraron API Keys.")
            print("👉 Crea un archivo '.env' en esta carpeta con la variable:")
            print("   GEMINI_API_KEYS=AQ_Key1...,AQ_Key2...")
            sys.exit(1)
        else:
            print(f"🔑 API Keys cargadas: {len(self.api_keys)} (Cuota estimada: {len(self.api_keys) * 15} RPM)")

        # 2. Comprobación de Flameshot
        try:
            subprocess.run(["flameshot", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print("📸 Caputador (Flameshot): OK")
        except FileNotFoundError:
            print("❌ ERROR: 'flameshot' no está instalado. Instálalo con: sudo apt install flameshot")
            sys.exit(1)

        self.key_index = 0
        self.modelos = [
            "gemini-3.8-flash",
            "gemini-flash-latest",
            "gemini-flash-lite-latest"
        ]
        self.cache = {}
        self.procesando = False
        self.session = requests.Session()

        # Icono de bandeja persistente
        self.tray_icon = pystray.Icon(
            "kahoot_indicator",
            crear_imagen_emoji(None),
            title="Kahoot Winner"
        )
        
        print("🟢 TODO OK: Escuchando teclado.")
        print("👉 Pulsa F9 para capturar | Pulsa F10 para salir")
        print("=" * 60)

    def mostrar_resultado(self, emoji):
        """Muestra el punto de color en la barra superior durante 2.5s y vuelve a transparente"""
        def _animar():
            self.tray_icon.icon = crear_imagen_emoji(emoji)
            time.sleep(2.5)
            self.tray_icon.icon = crear_imagen_emoji(None)

        threading.Thread(target=_animar, daemon=True).start()

    def get_next_key(self):
        key = self.api_keys[self.key_index]
        self.key_index = (self.key_index + 1) % len(self.api_keys)
        return key

    def capture(self):
        try:
            res = subprocess.run(
                ["flameshot", "gui", "-r"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                check=True
            )
            if not res.stdout:
                return None
            return Image.open(io.BytesIO(res.stdout)).convert("RGB")
        except Exception as e:
            print(f"❌ Error al capturar pantalla: {e}")
            return None

    def get_color_from_image(self, img):
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format='JPEG', quality=70)
        img_bytes = img_byte_arr.getvalue()

        img_hash = hashlib.md5(img_bytes).hexdigest()[:12]
        if img_hash in self.cache:
            print(f"💾 Caché hit -> {self.cache[img_hash]}")
            return self.cache[img_hash]

        b64_img = base64.b64encode(img_bytes).decode('utf-8')
        
        prompt = """Mira la imagen con la pregunta de Kahoot y sus opciones.
¿Cuál es la respuesta correcta?
Responde ÚNICAMENTE con uno de estos 4 emojis según el color del botón correcto:
🔴 (Rojo)
🟢 (Verde)
🔵 (Azul)
🟡 (Amarillo)

Tu respuesta debe ser EXCLUSIVAMENTE el emoji."""

        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": "image/jpeg", "data": b64_img}}
                ]
            }],
            "generationConfig": {"temperature": 0.0, "maxOutputTokens": 10}
        }

        for modelo in self.modelos:
            for _ in range(2):
                current_key = self.get_next_key()
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={current_key}"
                
                try:
                    resp = self.session.post(url, json=payload, timeout=3.5)
                    
                    if resp.status_code in [429, 503] or resp.status_code == 404:
                        continue
                        
                    if resp.status_code != 200:
                        print(f"⚠️ Error HTTP {resp.status_code}")
                        return "❓"

                    data = resp.json()
                    resp_text = data['candidates'][0]['content']['parts'][0]['text'].strip()

                    for em in ["🔴", "🟢", "🔵", "🟡"]:
                        if em in resp_text:
                            self.cache[img_hash] = em
                            return em

                    resp_lower = resp_text.lower()
                    if "rojo" in resp_lower or "red" in resp_lower: return "🔴"
                    if "verde" in resp_lower or "green" in resp_lower: return "🟢"
                    if "azul" in resp_lower or "blue" in resp_lower: return "🔵"
                    if "amarillo" in resp_lower or "yellow" in resp_lower: return "🟡"

                    return "❓"
                except Exception:
                    continue

        return "⏱️"

    def procesar(self):
        if self.procesando:
            return
        self.procesando = True
        inicio = time.time()

        print("\n⚡ Capturando imagen...")
        img = self.capture()
        if img:
            emoji = self.get_color_from_image(img)
            duracion = time.time() - inicio
            print(f"🎯 Respuesta: {emoji} (Procesado en {duracion:.2f}s)")
            self.mostrar_resultado(emoji)
        else:
            print("⚠️ Captura cancelada o vacía.")

        self.procesando = False

    def run(self):
        def on_press(key):
            if key == keyboard.Key.f9 and not self.procesando:
                threading.Thread(target=self.procesar, daemon=True).start()
            elif key == keyboard.Key.f10:
                print("\n👋 Cerrando Kahoot Winner...")
                self.tray_icon.stop()
                return False

        # Iniciar captura de teclado
        keyboard.Listener(on_press=on_press).start()

        # Iniciar icono en segundo plano
        self.tray_icon.run()


if __name__ == "__main__":
    KahootWinnerBar().run()
